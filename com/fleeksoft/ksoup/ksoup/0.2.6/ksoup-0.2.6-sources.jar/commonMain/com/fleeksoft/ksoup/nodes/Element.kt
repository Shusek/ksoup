/*
 * Kotlin port of jsoup's Element.java
 * Copyright © 2009–2025 Jonathan Hedley
 * Copyright © 2023–2025 FLEEK SOFT
 * Licensed under the MIT License
 * https://jsoup.org
 */

package com.fleeksoft.ksoup.nodes

import co.touchlab.stately.concurrency.Synchronizable
import co.touchlab.stately.concurrency.synchronize
import com.fleeksoft.ksoup.KmpJsExport
import com.fleeksoft.ksoup.exception.PatternSyntaxException
import com.fleeksoft.ksoup.helper.Validate
import com.fleeksoft.ksoup.helper.Validate.isTrue
import com.fleeksoft.ksoup.internal.Normalizer
import com.fleeksoft.ksoup.internal.Normalizer.normalize
import com.fleeksoft.ksoup.internal.QuietAppendable
import com.fleeksoft.ksoup.internal.StringUtil
import com.fleeksoft.ksoup.internal.WeakReference
import com.fleeksoft.ksoup.nodes.NodeUtils.outputSettings
import com.fleeksoft.ksoup.nodes.NodeUtils.parser
import com.fleeksoft.ksoup.nodes.TextNode.Companion.lastCharIsWhitespace
import com.fleeksoft.ksoup.parser.ParseSettings
import com.fleeksoft.ksoup.parser.Parser
import com.fleeksoft.ksoup.parser.Tag
import com.fleeksoft.ksoup.parser.TokenQueue.Companion.escapeCssIdentifier
import com.fleeksoft.ksoup.ported.AtomicBoolean
import com.fleeksoft.ksoup.ported.Consumer
import com.fleeksoft.ksoup.ported.jsSupportedRegex
import com.fleeksoft.ksoup.select.*
import com.fleeksoft.ksoup.select.Collector.findFirst
import com.fleeksoft.ksoup.select.Selector.evaluatorOf
import kotlin.js.JsExport
import kotlin.js.JsName
import kotlin.jvm.JvmOverloads
import kotlin.reflect.KClass


/**
 * An HTML Element consists of a tag name, attributes, and child nodes (including text nodes and other elements).
 *
 *
 * From an Element, you can extract data, traverse the node graph, and manipulate the HTML.
 */

@KmpJsExport
public open class Element : Node, Iterable<Element> {
    private val lock = Synchronizable()

    @JsName("_tag")
    var tag: Tag
        protected set
    private var _baseUri: String? = null // just for clone

    @JsName("_childNodes")
    public var childNodes: NodeList = EmptyNodeList
        protected set

    // field is nullable but all methods for attributes are non-null
    internal var attributes: Attributes? = null

    /**
     * Create a new, standalone element, in the specified namespace.
     * @param tag tag name
     * @param namespace namespace for this element
     */
    @JsExport.Ignore
    public constructor(tag: String, namespace: String) : this(
        Tag.valueOf(
            tag,
            namespace,
            ParseSettings.preserveCase,
        ),
        null,
    )

    /**
     * Create a new, standalone element, in the HTML namespace.
     * @param tag tag name
     * @see .Element
     */
    @JsExport.Ignore
    public constructor(tag: String) : this(tag, Parser.NamespaceHtml)

    /**
     * Create a new, standalone Element. (Standalone in that it has no parent.)
     *
     * @param tag tag of this element
     * @param baseUri the base URI (optional, may be null to inherit from parent, or "" to clear parent's)
     * @param attributes initial attributes (optional, may be null)
     * @see #appendChild(Node)
     * @see #appendElement(String)
     */
    @JsExport.Ignore
    public constructor(tag: Tag, baseUri: String?, attributes: Attributes?) {
        childNodes = EmptyNodeList
        this.attributes = attributes
        this.tag = tag
        _baseUri = baseUri
        if (!StringUtil.isBlank(baseUri)) this.setBaseUri(baseUri!!)
    }

    /**
     * Create a new Element from a Tag and a base URI.
     *
     * @param tag element tag
     * @param baseUri the base URI of this element. Optional, and will inherit from its parent, if any.
     * @see Tag.valueOf
     */
    @JsExport.Ignore
    public constructor(tag: Tag, baseUri: String?) : this(tag, baseUri, null)

    /**
     * Internal test to check if a nodelist object has been created.
     */
    public fun hasChildNodes(): Boolean {
        return childNodes != EmptyNodeList
    }

    public override fun ensureChildNodes(): MutableList<Node> {
        if (childNodes == EmptyNodeList) {
            childNodes = NodeList(4)
        }
        return childNodes
    }

    public override fun hasAttributes(): Boolean {
        return attributes != null
    }

    override fun attributes(): Attributes {
        if (attributes == null) {
            // not using hasAttributes, as doesn't clear warning
            attributes = Attributes()
        }
        return attributes!!
    }

    override fun baseUri(): String {
        val baseUri = searchUpForAttribute(this, BaseUriKey)
        return baseUri ?: ""
    }

    public override fun doSetBaseUri(baseUri: String?) {
        attributes().put(BaseUriKey, baseUri)
    }

    override fun childNodeSize(): Int {
        return childNodes.size
    }

    override fun nodeName(): String {
        return tag.tagName
    }

    /**
     * Get the name of the tag for this element. E.g. `div`. If you are using [ case preserving parsing][ParseSettings.preserveCase], this will return the source's original case.
     *
     * @return the tag name
     */
    public fun tagName(): String {
        return tag.tagName
    }

    /**
     * Get the normalized name of this Element's tag. This will always be the lower-cased version of the tag, regardless
     * of the tag case preserving setting of the parser. For e.g., `<DIV>` and `<div>` both have a
     * normal name of `div`.
     * @return normal name
     */
    override fun normalName(): String {
        return tag.normalName()
    }

    /**
     * Test if this Element has the specified normalized name, and is in the specified namespace.
     * @param normalName a normalized element name (e.g. `div`).
     * @param namespace the namespace
     * @return true if the element's normal name matches exactly, and is in the specified namespace
     */
    @JsName("elementIs")
    public fun elementIs(
        normalName: String?,
        namespace: String,
    ): Boolean {
        return tag.normalName() == normalName && tag.namespace() == namespace
    }

    /**
     * Change (rename) the tag of this element. For example, convert a `<span>` to a `<div>` with
     * `el.tagName("div");`.
     *
     * @param tagName new tag name for this element
     * @param namespace the new namespace for this element
     * @return this element, for chaining
     * @see Elements.tagName
     */

    /**
     * Change (rename) the tag of this element. For example, convert a `<span>` to a `<div>` with
     * `el.tagName("div");`.
     *
     * @param tagName new tag name for this element
     * @return this element, for chaining
     * @see Elements.tagName
     */
    @JvmOverloads
    @JsExport.Ignore
    public fun tagName(tagName: String, namespace: String = tag.namespace()): Element {
        Validate.notEmptyParam(tagName, "tagName")
        Validate.notEmptyParam(namespace, "namespace")
        val parser = parser(this)
        tag = parser.tagSet().valueOf(tagName, namespace, parser.settings()) // maintains the case option of the original parse
        return this
    }

    /**
     * Get the Tag for this element.
     *
     * @return the tag object
     */
    public fun tag(): Tag {
        return tag
    }

    /**
     * Change the Tag of this element.
     * @param tag the new tag
     * @return this element, for chaining
     */
    @JsName("setTag")
    fun tag(tag: Tag): Element {
        this.tag = tag
        return this
    }

    public fun isBlock(): Boolean = tag.isBlock()

    /**
     * Get the `id` attribute of this element.
     *
     * @return The id attribute, if present, or an empty string if not.
     */
    public fun id(): String {
        return if (attributes != null) attributes!!.getIgnoreCase("id") else ""
    }

    /**
     * Set the `id` attribute of this element.
     * @param id the ID value to use
     * @return this Element, for chaining
     */
    @JsName("setId")
    public fun id(id: String): Element {
        attr("id", id)
        return this
    }

    /**
     * Set an attribute value on this element. If this element already has an attribute with the
     * key, its value is updated; otherwise, a new attribute is added.
     *
     * @return this element
     */
    override fun attr(attributeKey: String, attributeValue: String?): Element {
        super.attr(attributeKey, attributeValue)
        return this
    }

    /**
     * Set a boolean attribute value on this element. Setting to `true` sets the attribute value to "" and
     * marks the attribute as boolean so no value is written out. Setting to `false` removes the attribute
     * with the same key if it exists.
     *
     * @param attributeKey the attribute key
     * @param attributeValue the attribute value
     *
     * @return this element
     */
    @JsName("setBooleanAttr")
    public fun attr(attributeKey: String, attributeValue: Boolean): Element {
        attributes().put(attributeKey, attributeValue)
        return this
    }

    /**
     * Get an Attribute by key. Changes made via [Attribute.setKey], [Attribute.setValue] etc
     * will cascade back to this Element.
     * @param key the (case-sensitive) attribute key
     * @return the Attribute for this key, or null if not present.
     */
    public fun attribute(key: String?): Attribute? {
        return if (hasAttributes()) attributes().attribute(key) else null
    }

    /**
     * Get this element's HTML5 custom data attributes. Each attribute in the element that has a key
     * starting with "data-" is included the dataset.
     *
     *
     * E.g., the element `<div data-package="com.fleeksoft.ksoup" data-language="Java" class="group">...` has the dataset
     * `package=com.fleeksoft.ksoup, language=java`.
     *
     *
     * This map is a filtered view of the element's attribute map. Changes to one map (add, remove, update) are reflected
     * in the other map.
     *
     *
     * You can find elements that have data attributes using the `[^data-]` attribute key prefix selector.
     * @return a map of `key=value` custom data attributes.
     */
    public fun dataset(): Attributes.Dataset {
        return attributes().dataset()
    }

    override fun parent(): Element? {
        return _parentNode as? Element
    }

    /**
     * Get this element's parent and ancestors, up to the document root.
     * @return this element's stack of parents, starting with the closest first.
     */
    public fun parents(): Elements {
        val parents = Elements()
        var parent = parent()
        while (parent != null && !parent.nameIs("#root")) {
            parents.add(parent)
            parent = parent.parent()
        }
        return parents
    }

    /**
     * Get a child element of this element, by its 0-based index number.
     *
     *
     * Note that an element can have both mixed Nodes and Elements as children. This method inspects
     * a filtered list of children that are elements, and the index is based on that filtered list.
     *
     *
     * @param index the index number of the element to retrieve
     * @return the child element, if it exists, otherwise throws an `IndexOutOfBoundsException`
     * @see .childNode
     */
    public fun child(index: Int): Element {
        Validate.isTrue(index >= 0, "Index must be >= 0")
        val cached: List<Element>? = cachedChildren()
        if (cached != null) return cached[index]

        // otherwise, iter on elementChild; saves creating list
        val size = childNodes.size
        var i = 0
        var e = 0
        while (i < size) {
            // direct iter is faster than chasing firstElSib, nextElSibd
            val node: Node? = childNodes[i]
            if (node is Element) {
                if (e++ == index) return node
            }
            i++
        }
        throw IndexOutOfBoundsException("No child at index: $index")
    }

    /**
     * Get the number of child nodes of this element that are elements.
     *
     *
     * This method works on the same filtered list like [.child]. Use [.childNodes] and [ ][.childNodeSize] to get the unfiltered Nodes (e.g. includes TextNodes etc.)
     *
     *
     * @return the number of child nodes that are elements
     * @see .children
     * @see .child
     */
    public fun childrenSize(): Int {
        if (childNodeSize() == 0) return 0
        return childElementsList().size // gets children into cache; faster subsequent child(i) if unmodified
    }

    /**
     * Get this element's child elements.
     *
     *
     * This is effectively a filter on [.childNodes] to get Element nodes.
     *
     * @return child elements. If this element has no children, returns an empty list.
     * @see .childNodes
     */
    public fun children(): Elements {
        return Elements(childElementsList())
    }

    /**
     * Maintains a shadow copy of this element's child elements. If the nodelist is changed, this cache is invalidated.
     * @return a list of child elements
     */
    public fun childElementsList(): List<Element> {
        if (childNodeSize() == 0) return EmptyChildren // short circuit creating empty

        // set atomically, so works in multi-thread. Calling methods look like reads, so should be thread-safe
        return lock.synchronize {
            var children: List<Element>? = cachedChildren()
            if (children == null) {
                children = filterNodes<Element>(Element::class)
                stashChildren(children)
            }
            children
        }
    }

    // Returns the cached child elements if they exist, and if the modCount matches
    fun cachedChildren(): List<Element>? {
        if (attributes == null || !attributes!!.hasUserData()) return null // don't create empty userdata
        val userData = attributes!!.userData()

        @Suppress("UNCHECKED_CAST")
        val ref = userData[childElsKey] as? WeakReference<List<Element>>
        val els = ref?.get()
        if (els != null) {
            val modCount = userData[childElsMod] as? Int
            if (modCount != null && modCount == childNodes.modCount())
                return els
        }
        return null
    }

    // Caches the child elements into the attribute user data.
    private fun stashChildren(els: List<Element>) {
        val userData = attributes().userData()
        val ref = WeakReference(els)
        userData[childElsKey] = ref
        userData[childElsMod] = childNodes.modCount()
    }

    /**
     * Returns a Stream of this Element and all of its descendant Elements. The stream has document order.
     * @return a stream of this element and its descendants.
     * @see .nodeStream
     */
    public fun stream(): Sequence<Element> {
        return NodeUtils.stream(this, Element::class)
    }

    private inline fun <reified T : Any> filterNodes(clazz: KClass<T>): List<T> {
        return childNodes.filterIsInstance<T>()
    }

    /**
     * Get this element's child text nodes. The list is unmodifiable but the text nodes may be manipulated.
     *
     *
     * This is effectively a filter on [.childNodes] to get Text nodes.
     * @return child text nodes. If this element has no text nodes, returns an
     * empty list.
     *
     * For example, with the input HTML: `<p>One <span>Two</span> Three <br> Four</p>` with the `p` element selected:
     *
     *  * `p.text()` = `"One Two Three Four"`
     *  * `p.ownText()` = `"One Three Four"`
     *  * `p.children()` = `Elements[<span>, <br>]`
     *  * `p.childNodes()` = `List<Node>["One ", <span>, " Three ", <br>, " Four"]`
     *  * `p.textNodes()` = `List<TextNode>["One ", " Three ", " Four"]`
     *
     */
    public fun textNodes(): List<TextNode> {
        return filterNodes(TextNode::class)
    }

    /**
     * Get this element's child data nodes. The list is unmodifiable but the data nodes may be manipulated.
     *
     *
     * This is effectively a filter on [.childNodes] to get Data nodes.
     *
     * @return child data nodes. If this element has no data nodes, returns an
     * empty list.
     * @see .data
     */
    public fun dataNodes(): List<DataNode> {
        return filterNodes(DataNode::class)
    }

    /**
     * Find elements that match the {@link Selector} CSS query, with this element as the starting context. Matched elements
     * may include this element, or any of its descendents.
     * <p>If the query starts with a combinator (e.g. {@code *} or {@code >}), that will combine to this element.</p>
     * <p>This method is generally more powerful to use than the DOM-type {@code getElementBy*} methods, because
     * multiple filters can be combined, e.g.:</p>
     * <ul>
     * <li>{@code el.select("a[href]")} - finds links ({@code a} tags with {@code href} attributes)</li>
     * <li>{@code el.select("a[href*=example.com]")} - finds links pointing to example.com (loosely)</li>
     * <li>{@code el.select("* div")} - finds all divs that descend from this element (and excludes this element)</li>
     * <li>{@code el.select("> div")} - finds all divs that are direct children of this element (and excludes this element)</li>
     * </ul>
     * <p>See the query syntax documentation in {@link Selector}.</p>
     * <p>Also known as {@code querySelectorAll()} in the Web DOM.</p>
     *
     * @param cssQuery a {@link Selector} CSS-like query
     * @return an {@link Elements} list containing elements that match the query (empty if none match)
     * @see Selector selector query syntax
     * @see #select(Evaluator)
     * @throws Selector.SelectorParseException (unchecked) on an invalid CSS query.
     */
    public fun select(cssQuery: String): Elements {
        return Selector.select(cssQuery, this)
    }

    /**
     * Find elements that match the supplied Evaluator. This has the same functionality as [.select], but
     * may be useful if you are running the same query many times (on many documents) and want to save the overhead of
     * repeatedly parsing the CSS query.
     * @param evaluator an element evaluator
     * @return an [Elements] list containing elements that match the query (empty if none match)
     * @see Selector#evaluatorOf(String css)
     */
    @JsExport.Ignore
    public fun select(evaluator: Evaluator): Elements {
        return Selector.select(evaluator, this)
    }

    /**
     * Selects elements from the given root that match the specified [Selector] CSS query, with this element as the
     * starting context, and returns them as a lazy Stream. Matched elements may include this element, or any of its
     * children.
     *
     *
     * Unlike [.select], which returns a complete list of all matching elements, this method returns a
     * [Stream] that processes elements lazily as they are needed. The stream operates in a "pull" model — elements
     * are fetched from the root as the stream is traversed. You can use standard `Stream` operations such as
     * `filter`, `map`, or `findFirst` to process elements on demand.
     *
     *
     * @param cssQuery a [Selector] CSS-like query
     * @return a [Stream] containing elements that match the query (empty if none match)
     * @throws Selector.SelectorParseException (unchecked) on an invalid CSS query.
     * @see Selector selector query syntax
     * @see #selectStream(Evaluator eval)
     */
    fun selectStream(cssQuery: String): Sequence<Element> {
        return Selector.selectStream(cssQuery, this)
    }

    /**
     * Find the first Element that matches the [Selector] CSS query, with this element as the starting context.
     *
     * This is effectively the same as calling `element.select(query).first()`, but is more efficient as query
     * execution stops on the first hit.
     *
     * Also known as `querySelector()` in the Web DOM.
     * @param cssQuery cssQuery a [Selector] CSS-like query
     * @return the first matching element, or **`null`** if there is no match.
     * @see .expectFirst
     */
    public fun selectFirst(cssQuery: String): Element? {
        return Selector.selectFirst(cssQuery, this)
    }

    /**
     * Finds the first Element that matches the supplied Evaluator, with this element as the starting context, or
     * `null` if none match.
     *
     * @param evaluator an element evaluator
     * @return the first matching element (walking down the tree, starting from this element), or `null` if none
     * match.
     */
    @JsExport.Ignore
    public fun selectFirst(evaluator: Evaluator): Element? {
        return findFirst(evaluator, this)
    }

    /**
     * Just like [.selectFirst], but if there is no match, throws an [IllegalArgumentException]. This
     * is useful if you want to simply abort processing on a failed match.
     * @param cssQuery a [Selector] CSS-like query
     * @return the first matching element
     * @throws IllegalArgumentException if no match is found
     */
    public fun expectFirst(cssQuery: String): Element {
        return Validate.expectNotNull(
            Selector.selectFirst(cssQuery, this),
            if (parent() != null) "No elements matched the query '$cssQuery' on element '${this.tagName()}'." else "No elements matched the query '$cssQuery' in the document."
        )
    }

    /**
     * Find nodes that match the supplied [Evaluator], with this element as the starting context. Matched
     * nodes may include this element, or any of its descendents.
     *
     * @param evaluator an evaluator
     * @return a list of nodes that match the query (empty if none match)
     */
    @JsExport.Ignore
    fun selectNodes(evaluator: Evaluator): Nodes<Node> {
        return selectNodes(evaluator, Node::class)
    }

    /**
     * Find nodes that match the supplied [Selector] CSS query, with this element as the starting context. Matched
     * nodes may include this element, or any of its descendents.
     *
     * To select leaf nodes, the query should specify the node type, e.g. `::text`,
     * `::comment`, `::data`, `::leafnode`.
     *
     * @param cssQuery a [Selector] CSS query
     * @return a list of nodes that match the query (empty if none match)
     */
    fun selectNodes(cssQuery: String): Nodes<Node> {
        return selectNodes(cssQuery, Node::class)
    }

    /**
     * Find nodes that match the supplied Evaluator, with this element as the starting context. Matched
     * nodes may include this element, or any of its descendents.
     *
     * @param evaluator an evaluator
     * @param type the type of node to collect (e.g. [Element], [LeafNode], [TextNode] etc)
     * @param <T> the type of node to collect
     * @return a list of nodes that match the query (empty if none match)
    </T> */
    @JsExport.Ignore
    fun <T : Node> selectNodes(evaluator: Evaluator, type: KClass<T>): Nodes<T> {
        return Collector.collectNodes(evaluator, this, type)
    }

    /**
     * Find nodes that match the supplied [Selector] CSS query, with this element as the starting context. Matched
     * nodes may include this element, or any of its descendents.
     *
     * To select specific node types, use `::text`, `::comment`, `::leafnode`, etc. For example, to
     * select all text nodes under `p` elements:
     * <pre>    Nodes&lt;TextNode&gt; textNodes = doc.selectNodes("p ::text", TextNode.class);</pre>
     *
     * @param cssQuery a [Selector] CSS query
     * @param type the type of node to collect (e.g. [Element], [LeafNode], [TextNode] etc)
     * @param <T> the type of node to collect
     * @return a list of nodes that match the query (empty if none match)
    </T> */
    @JsExport.Ignore
    fun <T : Node> selectNodes(cssQuery: String, type: KClass<T>): Nodes<T> {
        Validate.notEmpty(cssQuery)
        return selectNodes(Selector.evaluatorOf(cssQuery), type)
    }

    /**
     * Find the first Node that matches the [Selector] CSS query, with this element as the starting context.
     *
     * This is effectively the same as calling `element.selectNodes(query).first()`, but is more efficient as
     * query
     * execution stops on the first hit.
     *
     * Also known as `querySelector()` in the Web DOM.
     *
     * @param cssQuery cssQuery a [Selector] CSS-like query
     * @return the first matching node, or **`null`** if there is no match.
     * @see .expectFirst
     */
    fun <T : Node> selectFirstNode(cssQuery: String, type: KClass<T>): T? {
        return selectFirstNode(evaluatorOf(cssQuery), type)
    }

    /**
     * Finds the first Node that matches the supplied Evaluator, with this element as the starting context, or
     * `null` if none match.
     *
     * @param evaluator an element evaluator
     * @return the first matching node (walking down the tree, starting from this element), or `null` if none
     * match.
     */
    @JsExport.Ignore
    fun <T : Node> selectFirstNode(evaluator: Evaluator, type: KClass<T>): T? {
        return Collector.findFirstNode(evaluator, this, type)
    }

    /**
     * Just like [.selectFirstNode], but if there is no match, throws an
     * [IllegalArgumentException]. This is useful if you want to simply abort processing on a failed match.
     *
     * @param cssQuery a [Selector] CSS-like query
     * @return the first matching node
     * @throws IllegalArgumentException if no match is found
     */
    fun <T : Node> expectFirstNode(cssQuery: String, type: KClass<T>): T {
        return Validate.expectNotNull(
            selectFirstNode(cssQuery, type),
            if (parent() != null) "No nodes matched the query '${cssQuery}' on element '${this.tagName()}'." else "No nodes matched the query '${cssQuery}' in the document.",
        )
    }

    /**
     * Checks if this element matches the given [Selector] CSS query. Also knows as `matches()` in the Web
     * DOM.
     *
     * @param cssQuery a [Selector] CSS query
     * @return if this element matches the query
     */
    public fun `is`(cssQuery: String): Boolean {
        return `is`(Selector.evaluatorOf(cssQuery))
    }

    /**
     * Check if this element matches the given evaluator.
     * @param evaluator an element evaluator
     * @return if this element matches
     */
    @JsExport.Ignore
    public fun `is`(evaluator: Evaluator?): Boolean {
        return evaluator!!.matches(root(), this)
    }

    /**
     * Find the closest element up the tree of parents that matches the specified CSS query. Will return itself, an
     * ancestor, or `null` if there is no such matching element.
     * @param cssQuery a [Selector] CSS query
     * @return the closest ancestor element (possibly itself) that matches the provided evaluator. `null` if not
     * found.
     */
    public fun closest(cssQuery: String): Element? {
        return closest(Selector.evaluatorOf(cssQuery))
    }

    /**
     * Find the closest element up the tree of parents that matches the specified evaluator. Will return itself, an
     * ancestor, or `null` if there is no such matching element.
     * @param evaluator a query evaluator
     * @return the closest ancestor element (possibly itself) that matches the provided evaluator. `null` if not
     * found.
     */
//    @Nullable
    @JsExport.Ignore
    public fun closest(evaluator: Evaluator): Element? {
        var el: Element? = this
        val root = root()
        do {
            if (evaluator.matches(root, el!!)) return el
            el = el.parent()
        } while (el != null)
        return null
    }

    /**
     * Insert a node to the end of this Element's children. The incoming node will be re-parented.
     *
     * @param child node to add.
     * @return this Element, for chaining
     * @see .prependChild
     * @see .insertChildren
     */
    public fun appendChild(child: Node): Element {
        // was - Node#addChildren(child). short-circuits an array create and a loop.
        reparentChild(child)
        ensureChildNodes()
        childNodes.add(child)
        child._siblingIndex = childNodes.size - 1
        return this
    }

    /**
     * Insert the given nodes to the end of this Element's children.
     *
     * @param children nodes to add
     * @return this Element, for chaining
     * @see .insertChildren
     */
    public fun appendChildren(children: Collection<Node>): Element {
        insertChildren(-1, children)
        return this
    }

    /**
     * Add this element to the supplied parent element, as its next child.
     *
     * @param parent element to which this element will be appended
     * @return this element, so that you can continue modifying the element
     */
    public fun appendTo(parent: Element): Element {
        parent.appendChild(this)
        return this
    }

    /**
     * Add a node to the start of this element's children.
     *
     * @param child node to add.
     * @return this element, so that you can add more child nodes or elements.
     */
    public fun prependChild(child: Node): Element {
        addChildren(0, child)
        return this
    }

    /**
     * Insert the given nodes to the start of this Element's children.
     *
     * @param children nodes to add
     * @return this Element, for chaining
     * @see .insertChildren
     */
    public fun prependChildren(children: Collection<Node>): Element {
        insertChildren(0, children)
        return this
    }

    /**
     * Inserts the given child nodes into this element at the specified index. Current nodes will be shifted to the
     * right. The inserted nodes will be moved from their current parent. To prevent moving, copy the nodes first.
     *
     * @param index 0-based index to insert children at. Specify `0` to insert at the start, `-1` at the
     * end
     * @param children child nodes to insert
     * @return this element, for chaining.
     */
    public fun insertChildren(index: Int, children: Collection<Node>): Element {
        var calculatedIndex = index
        val currentSize = childNodeSize()
        if (calculatedIndex < 0) calculatedIndex += currentSize + 1 // roll around
        isTrue(calculatedIndex >= 0 && calculatedIndex <= currentSize, "Insert position out of bounds.")
        addChildren(calculatedIndex, *children.toTypedArray())
        return this
    }

    /**
     * Inserts the given child nodes into this element at the specified index. Current nodes will be shifted to the
     * right. The inserted nodes will be moved from their current parent. To prevent moving, copy the nodes first.
     *
     * @param index 0-based index to insert children at. Specify `0` to insert at the start, `-1` at the
     * end
     * @param children child nodes to insert
     * @return this element, for chaining.
     */
    @JsExport.Ignore
    public fun insertChildren(
        index: Int,
        vararg children: Node,
    ): Element {
        var calculatedIndex = index
        val currentSize = childNodeSize()
        if (calculatedIndex < 0) calculatedIndex += currentSize + 1 // roll around
        Validate.isTrue(calculatedIndex in 0..currentSize, "Insert position out of bounds.")
        addChildren(calculatedIndex, *children)
        return this
    }

    /**
     * Create a new element by tag name and namespace, add it as this Element's last child.
     *
     * @param tagName the name of the tag (e.g. `div`).
     * @param namespace the namespace of the tag (e.g. [Parser.NamespaceHtml])
     * @return the new element, in the specified namespace
     */
    public fun appendElement(tagName: String, namespace: String = tag.namespace()): Element {
        val parser: Parser = parser(this)
        val child = Element(parser.tagSet().valueOf(tagName, namespace, parser.settings()), baseUri())
        appendChild(child)
        return child
    }

    /**
     * Create a new element by tag name and namespace, and add it as this Element's first child.
     *
     * @param tagName the name of the tag (e.g. {@code div}).
     * @param namespace the namespace of the tag (e.g. {@link Parser#NamespaceHtml})
     * @return the new element, in the specified namespace
     */
    @JvmOverloads
    public fun prependElement(tagName: String, namespace: String = tag.namespace()): Element {
        val parser = parser(this)
        val child = Element(parser.tagSet().valueOf(tagName, namespace, parser.settings()), baseUri())
        prependChild(child)
        return child
    }

    /**
     * Create and append a new TextNode to this element.
     *
     * @param text the (un-encoded) text to add
     * @return this element
     */
    public fun appendText(text: String): Element {
        val node = TextNode(text)
        appendChild(node)
        return this
    }

    /**
     * Create and prepend a new TextNode to this element.
     *
     * @param text the decoded text to add
     * @return this element
     */
    public fun prependText(text: String): Element {
        val node = TextNode(text)
        prependChild(node)
        return this
    }

    /**
     * Add inner HTML to this element. The supplied HTML will be parsed, and each node appended to the end of the children.
     * @param html HTML to add inside this element, after the existing HTML
     * @return this element
     * @see .html
     */
    public fun append(html: String): Element {
        val nodes: List<Node> = parser(this).parseFragmentInput(html, this, baseUri())
        addChildren(*nodes.toTypedArray())
        return this
    }

    /**
     * Add inner HTML into this element. The supplied HTML will be parsed, and each node prepended to the start of the element's children.
     * @param html HTML to add inside this element, before the existing HTML
     * @return this element
     * @see .html
     */
    public fun prepend(html: String): Element {
        val nodes: List<Node> = parser(this).parseFragmentInput(html, this, baseUri())
        addChildren(0, *nodes.toTypedArray())
        return this
    }

    /**
     * Insert the specified HTML into the DOM before this element (as a preceding sibling).
     *
     * @param html HTML to add before this element
     * @return this element, for chaining
     * @see .after
     */
    override fun before(html: String): Element {
        return super.before(html) as Element
    }

    /**
     * Insert the specified node into the DOM before this node (as a preceding sibling).
     * @param node to add before this element
     * @return this Element, for chaining
     * @see .after
     */
    override fun before(node: Node): Element {
        return super.before(node) as Element
    }

    /**
     * Insert the specified HTML into the DOM after this element (as a following sibling).
     *
     * @param html HTML to add after this element
     * @return this element, for chaining
     * @see .before
     */
    override fun after(html: String): Element {
        return super.after(html) as Element
    }

    /**
     * Insert the specified node into the DOM after this node (as a following sibling).
     * @param node to add after this element
     * @return this element, for chaining
     * @see .before
     */
    override fun after(node: Node): Element {
        return super.after(node) as Element
    }

    /**
     * Remove all the element's child nodes. Any attributes are left as-is. Each child node has its parent set to
     * `null`.
     * @return this element
     */
    override fun empty(): Element {
        // Detach each of the children -> parent links:

        // Detach each of the children -> parent links:
        val size = childNodes.size
        for (i in 0..<size) childNodes[i]._parentNode = null
        childNodes.clear()
        return this
    }

    /**
     * Wrap the supplied HTML around this element.
     *
     * @param html HTML to wrap around this element, e.g. `<div class="head"></div>`. Can be arbitrarily deep.
     * @return this element, for chaining.
     */
    override fun wrap(html: String): Element {
        return super.wrap(html) as Element
    }

    /**
     * Gets an #id selector for this element, if it has a unique ID. Otherwise, returns an empty string.
     *
     * @param ownerDoc the document that owns this element, if there is one
     */
    private fun uniqueIdSelector(ownerDoc: Document?): String {
        val id = id()
        if (!id.isEmpty()) { // check if the ID is unique and matches this
            val idSel = "#" + escapeCssIdentifier(id)
            if (ownerDoc != null) {
                val els = ownerDoc.select(idSel)
                if (els.size == 1 && els[0] === this) return idSel
            } else {
                return idSel
            }
        }
        return EmptyString
    }

    /**
     * Get a CSS selector that will uniquely select this element.
     *
     * If the element has an ID, returns #id; otherwise returns the parent (if any) CSS selector, followed by
     * {@literal '>'}, followed by a unique selector for the element (tag.class.class:nth-child(n)).
     *
     * @return the CSS Path that can be used to retrieve the element in a selector.
     */
    fun cssSelector(): String {
        val ownerDoc = ownerDocument()
        var idSel = uniqueIdSelector(ownerDoc)
        if (!idSel.isEmpty()) return idSel

        // No unique ID, work up the parent stack and find either a unique ID to hang from, or just a GP > Parent > Child chain
        val selector: StringBuilder = StringUtil.borrowBuilder()
        var el: Element? = this
        while (el != null && el !is Document) {
            idSel = el.uniqueIdSelector(ownerDoc)
            if (!idSel.isEmpty()) {
                selector.insert(0, idSel)
                break // found a unique ID to use as ancestor; stop
            }
            selector.insert(0, el.cssSelectorComponent())
            el = el.parent()
        }
        return StringUtil.releaseBuilder(selector)
    }

    private fun cssSelectorComponent(): String {
        // Escape tagname, and translate HTML namespace ns:tag to CSS namespace syntax ns|tag
        val tagName: String = escapeCssIdentifier(tagName()).replace("\\:", "|")
        val selector: StringBuilder = StringUtil.borrowBuilder().append(tagName)
        // String classes = StringUtil.join(classNames().stream().map(TokenQueue::escapeCssIdentifier).iterator(), ".");
        val escapedClasses: StringUtil.StringJoiner = StringUtil.StringJoiner(".")
        for (name in classNames()) escapedClasses.add(escapeCssIdentifier(name))
        val classes: String = escapedClasses.complete()
        if (classes.isNotEmpty()) selector.append('.').append(classes)
        val parent: Element? = parent()
        if (parent == null || parent is Document) {
            // don't add Document to selector, as will always have a html node
            return StringUtil.releaseBuilder(selector)
        }
        selector.insert(0, " > ")
        if (parent.select(selector.toString()).size > 1) {
            selector.append(":nth-child(${elementSiblingIndex() + 1})")
        }
        return StringUtil.releaseBuilder(selector)
    }

    /**
     * Get sibling elements. If the element has no sibling elements, returns an empty list. An element is not a sibling
     * of itself, so will not be included in the returned list.
     * @return sibling elements
     */
    public fun siblingElements(): Elements {
        if (_parentNode == null) return Elements()
        val elements = (_parentNode as Element).childElementsList()
        val siblings = Elements()
        for (el in elements) if (el != this) siblings.add(el)
        return siblings
    }

    /**
     * Get each of the sibling elements that come after this element.
     *
     * @return each of the element siblings after this element, or an empty list if there are no next sibling elements
     */
    public fun nextElementSiblings(): Elements {
        return nextElementSiblings(true)
    }

    /**
     * Get each of the element siblings before this element.
     *
     * @return the previous element siblings, or an empty list if there are none.
     */
    public fun previousElementSiblings(): Elements {
        return nextElementSiblings(false)
    }

    private fun nextElementSiblings(next: Boolean): Elements {
        val els = Elements()
        if (_parentNode == null) return els
        els.add(this)
        return if (next) els.nextAll() else els.prevAll()
    }

    /**
     * Gets the first Element sibling of this element. That may be this element.
     * @return the first sibling that is an element (aka the parent's first element child)
     */
    public fun firstElementSibling(): Element? {
        val parent: Element? = parent()
        return if (parent != null) {
            parent.firstElementChild()
        } else {
            this // orphan is its own first sibling
        }
    }

    /**
     * Get the list index of this element in its element sibling list. I.e. if this is the first element
     * sibling, returns 0.
     * @return position in element sibling list
     */
    public fun elementSiblingIndex(): Int {
        val parent: Element? = parent()
        return if (parent == null) {
            0
        } else {
            indexInList(
                this,
                parent.childElementsList(),
            )
        }
    }

    /**
     * Gets the last element sibling of this element. That may be this element.
     * @return the last sibling that is an element (aka the parent's last element child)
     */
    public fun lastElementSibling(): Element? {
        val parent: Element? = parent()
        return if (parent != null) {
            parent.lastElementChild()
        } else {
            this
        }
    }

    /**
     * Gets the first child of this Element that is an Element, or `null` if there is none.
     * @return the first Element child node, or null.
     * @see .firstChild
     * @see .lastElementChild
     */
    public fun firstElementChild(): Element? {
        val size = childNodes.size
        for (i in 0..<size) {
            val node: Node = childNodes[i]
            if (node is Element) return node
        }
        return null
    }

    /**
     * Gets the last child of this Element that is an Element, or @{code null} if there is none.
     * @return the last Element child node, or null.
     * @see .lastChild
     * @see .firstElementChild
     */
    public fun lastElementChild(): Element? {
        for (i in childNodes.indices.reversed()) {
            val node: Node = childNodes[i]
            if (node is Element) return node
        }
        return null
    }
    // DOM type methods

    /**
     * Finds elements, including and recursively under this element, with the specified tag name.
     * @param tagName The tag name to search for (case insensitively).
     * @return a matching unmodifiable list of elements. Will be empty if this element and none of its children match.
     */
    public fun getElementsByTag(tagName: String?): Elements {
        Validate.notEmpty(tagName)
        val normalizedTagName = normalize(tagName)
        return Collector.collect(Evaluator.Tag(normalizedTagName), this)
    }

    /**
     * Find an element by ID, including or under this element.
     *
     *
     * Note that this finds the first matching ID, starting with this element. If you search down from a different
     * starting point, it is possible to find a different element by ID. For unique element by ID within a Document,
     * use [Document.getElementById]
     * @param id The ID to search for.
     * @return The first matching element by ID, starting with this element, or null if none found.
     */
//    @Nullable
    public fun getElementById(id: String): Element? {
        Validate.notEmpty(id)
        return findFirst(Evaluator.Id(id), this)
    }

    /**
     * Find elements that have this class, including or under this element. Case-insensitive.
     *
     *
     * Elements can have multiple classes (e.g. `<div class="header round first">`). This method
     * checks each class, so you can find the above with `el.getElementsByClass("header");`.
     *
     * @param className the name of the class to search for.
     * @return elements with the supplied class name, empty if none
     * @see .hasClass
     * @see .classNames
     */
    public fun getElementsByClass(className: String): Elements {
        Validate.notEmpty(className)
        return Collector.collect(Evaluator.Class(className), this)
    }

    /**
     * Find elements that have a named attribute set. Case-insensitive.
     *
     * @param key name of the attribute, e.g. `href`
     * @return elements that have this attribute, empty if none
     */
    public fun getElementsByAttribute(key: String): Elements {
        Validate.notEmpty(key)
        val trimmedKey = key.trim { it <= ' ' }
        return Collector.collect(Evaluator.Attribute(trimmedKey), this)
    }

    /**
     * Find elements that have an attribute name starting with the supplied prefix. Use `data-` to find elements
     * that have HTML5 datasets.
     * @param keyPrefix name prefix of the attribute e.g. `data-`
     * @return elements that have attribute names that start with the prefix, empty if none.
     */
    public fun getElementsByAttributeStarting(keyPrefix: String): Elements {
        Validate.notEmpty(keyPrefix)
        val trimmedKeyPrefix = keyPrefix.trim { it <= ' ' }
        return Collector.collect(Evaluator.AttributeStarting(trimmedKeyPrefix), this)
    }

    /**
     * Find elements that have an attribute with the specific value. Case-insensitive.
     *
     * @param key name of the attribute
     * @param value value of the attribute
     * @return elements that have this attribute with this value, empty if none
     */
    public fun getElementsByAttributeValue(key: String, value: String): Elements {
        return Collector.collect(Evaluator.AttributeWithValue(key, value), this)
    }

    /**
     * Find elements that either do not have this attribute, or have it with a different value. Case-insensitive.
     *
     * @param key name of the attribute
     * @param value value of the attribute
     * @return elements that do not have a matching attribute
     */
    public fun getElementsByAttributeValueNot(key: String, value: String): Elements {
        return Collector.collect(Evaluator.AttributeWithValueNot(key, value), this)
    }

    /**
     * Find elements that have attributes that start with the value prefix. Case-insensitive.
     *
     * @param key name of the attribute
     * @param valuePrefix start of attribute value
     * @return elements that have attributes that start with the value prefix
     */
    public fun getElementsByAttributeValueStarting(key: String, valuePrefix: String): Elements {
        return Collector.collect(Evaluator.AttributeWithValueStarting(key, valuePrefix), this)
    }

    /**
     * Find elements that have attributes that end with the value suffix. Case-insensitive.
     *
     * @param key name of the attribute
     * @param valueSuffix end of the attribute value
     * @return elements that have attributes that end with the value suffix
     */
    public fun getElementsByAttributeValueEnding(key: String, valueSuffix: String): Elements {
        return Collector.collect(Evaluator.AttributeWithValueEnding(key, valueSuffix), this)
    }

    /**
     * Find elements that have attributes whose value contains the match string. Case-insensitive.
     *
     * @param key name of the attribute
     * @param match substring of value to search for
     * @return elements that have attributes containing this text
     */
    public fun getElementsByAttributeValueContaining(key: String, match: String): Elements {
        return Collector.collect(Evaluator.AttributeWithValueContaining(key, match), this)
    }

    /**
     * Find elements that have an attribute whose value matches the supplied regular expression.
     * @param key name of the attribute
     * @param pattern compiled regular expression to match against attribute values
     * @return elements that have attributes matching this regular expression
     */
    public fun getElementsByAttributeValueMatching(key: String, regex: Regex): Elements {
        return Collector.collect(Evaluator.AttributeWithValueMatching(key, regex), this)
    }

    /**
     * Find elements that have attributes whose values match the supplied regular expression.
     * @param key name of the attribute
     * @param regex regular expression to match against attribute values. You can use <a href="http://java.sun.com/docs/books/tutorial/essential/regex/pattern.html#embedded">embedded flags</a> (such as {@code (?i)} and {@code (?m)}) to control regex options.
     * @return elements that have attributes matching this regular expression
     */
    @JsExport.Ignore
    public fun getElementsByAttributeValueMatching(key: String, regex: String): Elements {
        val pattern: Regex = try {
            jsSupportedRegex(regex)
        } catch (e: PatternSyntaxException) {
            throw IllegalArgumentException("Pattern syntax error: $regex", e)
        }
        return Collector.collect(Evaluator.AttributeWithValueMatching(key, pattern), this)
    }

    /**
     * Find elements whose sibling index is less than the supplied index.
     * @param index 0-based index
     * @return elements less than index
     */
    public fun getElementsByIndexLessThan(index: Int): Elements {
        return Collector.collect(Evaluator.IndexLessThan(index), this)
    }

    /**
     * Find elements whose sibling index is greater than the supplied index.
     * @param index 0-based index
     * @return elements greater than index
     */
    public fun getElementsByIndexGreaterThan(index: Int): Elements {
        return Collector.collect(Evaluator.IndexGreaterThan(index), this)
    }

    /**
     * Find elements whose sibling index is equal to the supplied index.
     * @param index 0-based index
     * @return elements equal to index
     */
    public fun getElementsByIndexEquals(index: Int): Elements {
        return Collector.collect(Evaluator.IndexEquals(index), this)
    }

    /**
     * Find elements that contain the specified string. The search is case-insensitive. The text may appear directly
     * in the element, or in any of its descendants.
     * @param searchText to look for in the element's text
     * @return elements that contain the string, case-insensitive.
     * @see Element.text
     */
    public fun getElementsContainingText(searchText: String): Elements {
        return Collector.collect(Evaluator.ContainsText(searchText), this)
    }

    /**
     * Find elements that directly contain the specified string. The search is case-insensitive. The text must appear directly
     * in the element, not in any of its descendants.
     * @param searchText to look for in the element's own text
     * @return elements that contain the string, case-insensitive.
     * @see Element.ownText
     */
    @JsExport.Ignore
    public fun getElementsContainingOwnText(searchText: String): Elements {
        return Collector.collect(Evaluator.ContainsOwnText(searchText), this)
    }

    /**
     * Find elements whose text matches the supplied regular expression.
     * @param regex regular expression to match text against
     * @return elements matching the supplied regular expression.
     * @see Element.text
     */
    public fun getElementsMatchingText(regex: Regex): Elements {
        return Collector.collect(Evaluator.Matches(regex), this)
    }

    /**
     * Find elements whose text matches the supplied regular expression.
     * @param regex regular expression to match text against. You can use <a href="http://java.sun.com/docs/books/tutorial/essential/regex/pattern.html#embedded">embedded flags</a> (such as {@code (?i)} and {@code (?m)}) to control regex options.
     * @return elements matching the supplied regular expression.
     * @see Element#text()
     */
    @JsExport.Ignore
    public fun getElementsMatchingText(regex: String): Elements {
        val pattern: Regex =
            try {
                jsSupportedRegex(regex)
            } catch (e: PatternSyntaxException) {
                throw IllegalArgumentException("Pattern syntax error: $regex", e)
            }
        return Collector.collect(Evaluator.Matches(pattern), this)
    }

    /**
     * Find elements whose own text matches the supplied regular expression.
     * @param regex regular expression to match text against
     * @return elements matching the supplied regular expression.
     * @see Element.ownText
     */
    public fun getElementsMatchingOwnText(regex: Regex): Elements {
        return Collector.collect(Evaluator.MatchesOwn(regex), this)
    }

    /**
     * Find elements whose own text matches the supplied regular expression.
     * @param regex regular expression to match text against. You can use <a href="http://java.sun.com/docs/books/tutorial/essential/regex/pattern.html#embedded">embedded flags</a> (such as {@code (?i)} and {@code (?m)}) to control regex options.
     * @return elements matching the supplied regular expression.
     * @see Element#ownText()
     */
    @JsExport.Ignore
    public fun getElementsMatchingOwnText(regex: String): Elements {
        val pattern: Regex =
            try {
                jsSupportedRegex(regex)
            } catch (e: PatternSyntaxException) {
                throw IllegalArgumentException("Pattern syntax error: $regex", e)
            }
        return Collector.collect(Evaluator.MatchesOwn(pattern), this)
    }

    public fun getAllElements(): Elements = Collector.collect(Evaluator.AllElements(), this)

    /**
     * Gets the **normalized, combined text** of this element and all its children. Whitespace is normalized and
     * trimmed.
     *
     * For example, given HTML `<p>Hello  <b>there</b> now! </p>`, `p.text()` returns `"Hello there
     * now!"`
     *
     * If you do not want normalized text, use [.wholeText]. If you want just the text of this node (and not
     * children), use [.ownText]
     *
     * Note that this method returns the textual content that would be presented to a reader. The contents of data
     * nodes (such as `<script>` tags) are not considered text. Use [.data] or [.html] to retrieve
     * that content.
     *
     * @return decoded, normalized text, or empty string if none.
     * @see .wholeText
     * @see .ownText
     * @see .textNodes
     */
    public fun text(): String {
        val accum: StringBuilder = StringUtil.borrowBuilder()
        TextAccumulator(accum).traverse(this)
        return StringUtil.releaseBuilder(accum).trim()
    }

    private class TextAccumulator(private val accum: StringBuilder) : NodeVisitor {
        override fun head(
            node: Node,
            depth: Int,
        ) {
            if (node is TextNode) {
                appendNormalisedText(accum, node)
            } else if (node is Element) {
                if (accum.isNotEmpty() &&
                    (node.isBlock() || node.nameIs("br")) &&
                    !lastCharIsWhitespace(accum)
                ) {
                    accum.append(' ')
                }
            }
        }

        override fun tail(node: Node, depth: Int) {
            // make sure there is a space between block tags and immediately following text nodes or inline elements <div>One</div>Two should be "One Two".
            if (node is Element) {
                val next: Node? = node.nextSibling()
                if (!node.tag.isInline() && (next is TextNode || next is Element && next.tag.isInline()) && !lastCharIsWhitespace(accum)) {
                    accum.append(' ')
                }
            }
        }
    }

    /**
     * Get the non-normalized, decoded text of this element and its children, including only any newlines and spaces
     * present in the original source.
     * @return decoded, non-normalized text
     * @see .text
     * @see .wholeOwnText
     */
    public fun wholeText(): String {
        return wholeTextOf(nodeStream())
    }

    /**
     * An Element's nodeValue is its whole own text.
     */
    public override fun nodeValue(): String {
        return wholeOwnText()
    }


    /**
     * Get the non-normalized, decoded text of this element, <b>not including</b> any child elements, including any
     * newlines and spaces present in the original source.
     * @return decoded, non-normalized text that is a direct child of this Element
     * @see .text
     * @see .wholeText
     * @see .ownText
     */
    public fun wholeOwnText(): String {
        return wholeTextOf(childNodes().asSequence());
    }

    /**
     * Gets the (normalized) text owned by this element only; does not get the combined text of all children.
     *
     *
     * For example, given HTML `<p>Hello <b>there</b> now!</p>`, `p.ownText()` returns `"Hello now!"`,
     * whereas `p.text()` returns `"Hello there now!"`.
     * Note that the text within the `b` element is not returned, as it is not a direct child of the `p` element.
     *
     * @return decoded text, or empty string if none.
     * @see .text
     * @see .textNodes
     */
    public fun ownText(): String {
        val sb: StringBuilder = StringUtil.borrowBuilder()
        ownText(sb)
        return StringUtil.releaseBuilder(sb).trim()
    }

    private fun ownText(accum: StringBuilder) {
        for (i in 0 until childNodeSize()) {
            val child: Node = childNodes[i]
            if (child is TextNode) {
                appendNormalisedText(accum, child)
            } else if (child.nameIs("br") && !lastCharIsWhitespace(accum)) {
                accum.append(" ")
            }
        }
    }

    /**
     * Set the text of this element. Any existing contents (text or elements) will be cleared.
     *
     * As a special case, for `<script>` and `<style>` tags, the input text will be treated as data,
     * not visible text.
     * @param text decoded text
     * @return this element
     */
    @JsName("setText")
    public open fun text(text: String): Element {
        empty()
        // special case for script/style in HTML (or customs): should be data node
        if (tag().`is`(Tag.Data))
            appendChild(DataNode(text));
        else
            appendChild(TextNode(text));

        return this;
    }

    /**
     * Checks if the current element or any of its child elements contain non-whitespace text.
     * @return `true` if the element has non-blank text content, `false` otherwise.
     */
    public fun hasText(): Boolean {
        val hasText = AtomicBoolean(false)
        filter(
            object : NodeFilter {
                override fun head(
                    node: Node,
                    depth: Int,
                ): NodeFilter.FilterResult {
                    if (node is TextNode) {
                        if (!node.isBlank()) {
                            hasText.set(true)
                            return NodeFilter.FilterResult.STOP
                        }
                    }
                    return NodeFilter.FilterResult.CONTINUE
                }
            },
        )
        return hasText.get()
    }

    /**
     * Get the combined data of this element. Data is e.g. the inside of a `<script>` tag. Note that data is NOT the
     * text of the element. Use [.text] to get the text that would be visible to a user, and `data()`
     * for the contents of scripts, comments, CSS styles, etc.
     *
     * @return the data, or empty string if none
     *
     * @see .dataNodes
     */
    public fun data(): String {
        val sb: StringBuilder = StringUtil.borrowBuilder()
        traverse { childNode, depth ->
            when (childNode) {
                is DataNode -> {
                    sb.append(childNode.getWholeData())
                }

                is Comment -> {
                    sb.append(childNode.getData())
                }

                is CDataNode -> {
                    // this shouldn't really happen because the html parser won't see the cdata as anything special when parsing script.
                    // but in case another type gets through.
                    sb.append(childNode.getWholeText())
                }
            }
        }
        return StringUtil.releaseBuilder(sb)
    }

    /**
     * Gets the literal value of this element's "class" attribute, which may include multiple class names, space
     * separated. (E.g. on `<div class="header gray">` returns, "`header gray`")
     * @return The literal class attribute, or **empty string** if no class attribute set.
     */
    public fun className(): String {
        return attr("class").trim()
    }

    /**
     * Get each of the element's class names. E.g. on element `<div class="header gray">`,
     * returns a set of two elements `"header", "gray"`. Note that modifications to this set are not pushed to
     * the backing `class` attribute; use the [.classNames] method to persist them.
     * @return set of classnames, empty if no class attribute
     */
    public fun classNames(): MutableSet<String> {
        val names: List<String> = ClassSplit.split(className())
        val classNames: MutableSet<String> =
            LinkedHashSet(names)
        classNames.remove("") // if classNames() was empty, would include an empty class
        return classNames
    }

    /**
     * Set the element's `class` attribute to the supplied class names.
     * @param classNames set of classes
     * @return this element, for chaining
     */
    @JsName("setClassNames")
    public fun classNames(classNames: Set<String>): Element {
        if (classNames.isEmpty()) {
            attributes().remove("class")
        } else {
            attributes().put("class", StringUtil.join(classNames, " "))
        }
        return this
    }

    /**
     * Tests if this element has a class. Case-insensitive.
     * @param className name of class to check for
     * @return true if it does, false if not
     */
    // performance sensitive
    public fun hasClass(className: String): Boolean {
        if (attributes == null) return false
        val classAttr: String = attributes!!.getIgnoreCase("class")
        val len = classAttr.length
        val wantLen = className.length
        if (len == 0 || len < wantLen) {
            return false
        }

        // if both lengths are equal, only need compare the className with the attribute
        if (len == wantLen) {
            return className.equals(classAttr, ignoreCase = true)
        }

        // otherwise, scan for whitespace and compare regions (with no string or arraylist allocations)
        var inClass = false
        var start = 0
        for (i in 0 until len) {
            if (classAttr[i].isWhitespace()) {
                if (inClass) {
                    // white space ends a class name, compare it with the requested one, ignore case
                    if (i - start == wantLen &&
                        classAttr.regionMatches(
                            start,
                            className,
                            0,
                            wantLen,
                            ignoreCase = true,
                        )
                    ) {
                        return true
                    }
                    inClass = false
                }
            } else {
                if (!inClass) {
                    // we're in a class name : keep the start of the substring
                    inClass = true
                    start = i
                }
            }
        }

        // check the last entry
        return if (inClass && len - start == wantLen) {
            classAttr.regionMatches(start, className, 0, wantLen, ignoreCase = true)
        } else {
            false
        }
    }

    /**
     * Add a class name to this element's `class` attribute.
     * @param className class name to add
     * @return this element
     */
    public fun addClass(className: String): Element {
        val classes = classNames()
        classes.add(className)
        classNames(classes)
        return this
    }

    /**
     * Remove a class name from this element's `class` attribute.
     * @param className class name to remove
     * @return this element
     */
    public fun removeClass(className: String): Element {
        val classes = classNames()
        classes.remove(className)
        classNames(classes)
        return this
    }

    /**
     * Toggle a class name on this element's `class` attribute: if present, remove it; otherwise add it.
     * @param className class name to toggle
     * @return this element
     */
    public fun toggleClass(className: String): Element {
        val classes = classNames()
        if (classes.contains(className)) classes.remove(className) else classes.add(className)
        classNames(classes)
        return this
    }

    /**
     * Get the value of a form element (input, textarea, etc).
     * @return the value of the form element, or empty string if not set.
     */
    public fun value(): String {
        return if (elementIs("textarea", Parser.NamespaceHtml)) text() else attr("value")
    }

    /**
     * Set the value of a form element (input, textarea, etc).
     * @param value value to set
     * @return this element (for chaining)
     */
    @JsName("setValue")
    public fun value(value: String): Element {
        if (elementIs("textarea", Parser.NamespaceHtml)) text(value) else attr("value", value)
        return this
    }

    /**
     * Get the source range (start and end positions) of the end (closing) tag for this Element. Position tracking must be
     * enabled prior to parsing the content.
     * @return the range of the closing tag for this element, or {@code untracked} if its range was not tracked.
     * @see Parser#setTrackPosition(boolean)
     * @see Node#sourceRange()
     * @see Range#isImplicit()
     */
    public fun endSourceRange(): Range {
        return Range.of(this, false)
    }

    override fun outerHtmlHead(accum: QuietAppendable, out: Document.OutputSettings) {
        val tagName = safeTagName(out.syntax())
        accum.append('<').append(tagName)
        attributes?.html(accum, out)

        if (childNodes.isEmpty()) {
            val xmlMode = out.syntax() == Document.OutputSettings.Syntax.xml || tag.namespace() != Parser.NamespaceHtml
            if (xmlMode && (tag.`is`(Tag.SeenSelfClose) || (tag.isKnownTag() && (tag.isEmpty() || tag.isSelfClosing())))) {
                accum.append(" />")
            } else if (!xmlMode && tag.isEmpty()) {
                accum.append('>')
            } else {
                accum.append("></").append(tagName).append('>')
            }
        } else {
            accum.append('>')
        }
    }

    override fun outerHtmlTail(accum: QuietAppendable, out: Document.OutputSettings) {
        if (!childNodes.isEmpty())
            accum.append("</").append(safeTagName(out.syntax())).append('>')
        // if empty, we have already closed in htmlHead
    }

    /* If XML syntax, normalizes < to _ in tag name. */
    private fun safeTagName(syntax: Document.OutputSettings.Syntax): String? {
        return if (syntax == Document.OutputSettings.Syntax.xml) Normalizer.xmlSafeTagName(tagName()) else tagName()
    }

    /**
     * Retrieves the element's inner HTML. E.g. on a `<div>` with one empty `<p>`, would return
     * `<p></p>`. (Whereas [.outerHtml] would return `<div><p></p></div>`.)
     *
     * @return String of HTML.
     * @see .outerHtml
     */
    public fun html(): String {
        val sb = StringUtil.borrowBuilder()
        html(sb)
        val html = StringUtil.releaseBuilder(sb)
        return if (outputSettings(this).prettyPrint()) html.trim { it <= ' ' } else html
    }

    override fun <T : Appendable> html(appendable: T): T {
        var child = firstChild()
        if (child != null) {
            val printer = Printer.printerFor(child, QuietAppendable.wrap(appendable))
            while (child != null) {
                printer.traverse(child)
                child = child.nextSibling()
            }
        }
        return appendable
    }

    /**
     * Set this element's inner HTML. Clears the existing HTML first.
     * @param html HTML to parse and set into this element
     * @return this element
     * @see .append
     */
    @JsName("setHtml")
    public fun html(html: String): Element {
        empty()
        append(html)
        return this
    }

    //    Mimics Java’s clone, copying only primitive values and object references.
    override fun createClone(): Node {
        val clone = Element(this.tag, _baseUri)
        clone.attributes = attributes
        clone.childNodes = childNodes
        return clone
    }

    override fun clone(): Element {
        return super.clone() as Element
    }

    protected override fun doClone(parent: Node?): Element {
        val clone = super.doClone(parent) as Element
        clone.childNodes = NodeList(childNodes.size)
        clone.childNodes.addAll(childNodes) // the children then get iterated and cloned in Node.clone

        if (attributes != null) {
            clone.attributes = attributes?.clone()
            // clear any cached children
            clone.attributes!!.userData(Element.childElsKey, null)
        }

        return clone
    }

    public override fun shallowClone(): Element {
        // simpler than implementing a clone version with no child copy
        val baseUri = baseUri().ifEmpty { null }
        return Element(tag, baseUri, attributes?.clone())
    }

    // overrides of Node for call chaining
    override fun clearAttributes(): Element {
        if (attributes != null) {
            super.clearAttributes() // keeps internal attributes via iterator
            if (attributes!!.size == 0) attributes = null // only remove entirely if no internal attributes
        }

        return this
    }

    override fun removeAttr(attributeKey: String): Element {
        return super.removeAttr(attributeKey) as Element
    }

    override fun root(): Element {
        return super.root() as Element // probably a document, but always at least an element
    }

    override fun traverse(nodeVisitor: NodeVisitor): Element {
        return super.traverse(nodeVisitor) as Element
    }

    override fun forEachNode(action: Consumer<in Node>): Element {
        return super.forEachNode(action) as Element
    }

    /**
    Perform the supplied action on this Element and each of its descendant Elements, during a depth-first traversal.
    Elements may be inspected, changed, added, replaced, or removed.
    @param action the function to perform on the element
    @see Node#forEachNode(Consumer)
     */
    fun forEach(action: (Element) -> Unit) {
        stream().forEach(action)
    }

    override fun iterator(): Iterator<Element> {
        return NodeIterator<Element>(this, Element::class)
    }

    override fun filter(nodeFilter: NodeFilter): Element {
        return super.filter(nodeFilter) as Element
    }

    fun reindexChildren() {
        val size: Int = childNodes.size
        for (i in 0..<size) {
            childNodes[i]._siblingIndex = i
        }
        childNodes.validChildren = true
    }

    fun invalidateChildren() {
        childNodes.validChildren = false
    }

    fun hasValidChildren(): Boolean {
        return childNodes.validChildren
    }

    companion object {
        private const val childElsKey: String = "ksoup.childEls"
        private const val childElsMod: String = "ksoup.childElsMod"
        private val EmptyChildren: List<Element> = emptyList()
        private val EmptyNodeList: NodeList = NodeList(0)
        private val ClassSplit: Regex = Regex("\\s+")
        val BaseUriKey: String = Attributes.internalKey("baseUri")


        class NodeList(initialCapacity: Int) : MutableList<Node> {
            /** Tracks if the children have valid sibling indices. We only need to reindex on siblingIndex() demand. */
            var validChildren: Boolean = true
            private val list = ArrayList<Node>(initialCapacity)
            private var modCount = 0
            override fun iterator(): MutableIterator<Node> = list.toMutableList().iterator()

            override fun add(node: Node): Boolean {
                modCount++
                return list.add(node)
            }

            override fun remove(element: Node): Boolean {
                val result = list.remove(element)
                if (result) {
                    modCount++
                }

                return result
            }

            override fun addAll(elements: Collection<Node>): Boolean {
                val result = list.addAll(elements)
                if (result) {
                    modCount++
                }

                return result
            }

            override fun addAll(index: Int, elements: Collection<Node>): Boolean {
                val result = list.addAll(index, elements)
                if (result) {
                    modCount++
                }

                return result
            }

            override fun removeAll(elements: Collection<Node>): Boolean {
                val result = list.removeAll(elements)
                if (result) {
                    modCount++
                }

                return result
            }

            override fun retainAll(elements: Collection<Node>): Boolean {
                val result = list.retainAll(elements)
                if (result) {
                    modCount++
                }

                return result
            }

            override val size: Int
                get() = list.size

            override fun isEmpty(): Boolean = list.isEmpty()

            override fun contains(element: Node): Boolean = list.contains(element)

            override fun containsAll(elements: Collection<Node>): Boolean = list.containsAll(elements)

            override fun get(index: Int): Node = list[index]

            override fun indexOf(element: Node): Int = list.indexOf(element)

            override fun lastIndexOf(element: Node): Int = list.lastIndexOf(element)

            fun modCount(): Int = modCount

            fun incrementMod() {
                this.modCount++
            }

            override fun clear() {
                modCount++
                list.clear()
            }

            override fun set(index: Int, element: Node): Node {
                modCount++
                return list.set(index, element)
            }

            override fun add(index: Int, element: Node) {
                modCount++
                list.add(index, element)
            }

            override fun removeAt(index: Int): Node {
                modCount++
                return list.removeAt(index)
            }

            override fun listIterator(): MutableListIterator<Node> = list.listIterator()

            override fun listIterator(index: Int): MutableListIterator<Node> = list.listIterator(index)

            override fun subList(fromIndex: Int, toIndex: Int): MutableList<Node> = list.subList(fromIndex, toIndex)
        }

        fun searchUpForAttribute(start: Element, key: String): String? {
            var el: Element? = start
            while (el != null) {
                if (el.attributes?.hasKey(key) == true) return el.attributes!![key]
                el = el.parent()
            }
            return null
        }

        private fun <E : Element?> indexInList(search: Element, elements: List<E>): Int {
            val size = elements.size
            for (i in 0 until size) {
                if (elements[i] === search) return i
            }
            return 0
        }

        private fun wholeTextOf(nodeStream: Sequence<Node>): String {
            return nodeStream.map { node ->
                when {
                    node is TextNode -> node.getWholeText()
                    node.nameIs("br") -> "\n"
                    else -> ""
                }
            }.joinToString("")
        }

        private fun appendNormalisedText(
            accum: StringBuilder,
            textNode: TextNode,
        ) {
            val text: String = textNode.getWholeText()
            if (preserveWhitespace(textNode._parentNode) || textNode is CDataNode) {
                accum.append(text)
            } else {
                StringUtil.appendNormalisedWhitespace(
                    accum,
                    text,
                    lastCharIsWhitespace(accum),
                )
            }
        }

        fun preserveWhitespace(node: Node?): Boolean {
            // looks only at this element and five levels up, to prevent recursion & needless stack searches
            if (node is Element) {
                var el = node as Element?
                var i = 0
                do {
                    if (el!!.tag.preserveWhitespace()) return true
                    el = el.parent()
                    i++
                } while (i < 6 && el != null)
            }
            return false
        }
    }
}
