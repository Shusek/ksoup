package com.fleeksoft.ksoup.helper

import com.fleeksoft.ksoup.exception.ValidationException

/**
 * Validators to check that method arguments meet expectations.
 */
object Validate {

    /**
     * Verifies the input object is not null, and returns that object, maintaining its type. Effectively this casts a
     * nullable object to a non-null object.
     *
     * @param obj nullable object to cast to not-null
     * @param msg the String formatted message to include in the validation exception when thrown
     * @return the object, or throws an exception if it is null
     * @throws ValidationException if the object is null
     */
    fun <T> expectNotNull(obj: T?, msg: String? = null): T {
        if (obj == null) throw ValidationException(msg ?: "Object must not be null")
        else return obj
    }


    /**
     * Validates that the value is true
     * @param val object to test
     * @throws com.fleeksoft.ksoup.exception.ValidationException if the object is not true
     */
    fun isTrue(value: Boolean) {
        if (!value) throw ValidationException("Must be true")
    }

    /**
     * Validates that the value is true
     * @param val object to test
     * @param msg message to include in the Exception if validation fails
     * @throws com.fleeksoft.ksoup.exception.ValidationException if the object is not true
     */
    fun isTrue(value: Boolean, msg: String?) {
        if (!value) throw ValidationException(msg)
    }

    /**
     * Validates that the value is false
     * @param val object to test
     * @throws com.fleeksoft.ksoup.exception.ValidationException if the object is not false
     */
    fun isFalse(value: Boolean) {
        if (value) throw ValidationException("Must be false")
    }

    /**
     * Validates that the value is false
     * @param val object to test
     * @param msg message to include in the Exception if validation fails
     * @throws com.fleeksoft.ksoup.exception.ValidationException if the object is not false
     */
    fun isFalse(value: Boolean, msg: String?) {
        if (value) throw ValidationException(msg)
    }

    /**
     * Validates that the string is not null and is not empty
     * @param string the string to test
     * @throws com.fleeksoft.ksoup.exception.ValidationException if the string is null or empty
     */
    fun notEmpty(string: String?) {
        if (string.isNullOrEmpty()) throw ValidationException("String must not be empty")
    }

    /**
     * Validates that the string parameter is not null and is not empty
     * @param string the string to test
     * @param param the name of the parameter, for presentation in the validation exception.
     * @throws com.fleeksoft.ksoup.exception.ValidationException if the string is null or empty
     */
    fun notEmptyParam(string: String?, param: String?) {
        if (string.isNullOrEmpty()) {
            throw ValidationException("The '$param' parameter must not be empty.")
        }
    }

    /**
     * Validates that the string is not null and is not empty
     * @param string the string to test
     * @param msg message to include in the Exception if validation fails
     * @throws com.fleeksoft.ksoup.exception.ValidationException if the string is null or empty
     */
    fun notEmpty(string: String?, msg: String?) {
        if (string.isNullOrEmpty()) throw ValidationException(msg)
    }

    /**
     * Blow up if we reach an unexpected state.
     * @param msg message to think about
     * @throws IllegalStateException if we reach this state
     */
    fun wtf(msg: String?) {
        throw IllegalStateException(msg)
    }

    /**
     * Cause a failure.
     * @param msg message to output.
     * @throws IllegalStateException if we reach this state
     */
    fun fail(msg: String?) {
        throw ValidationException(msg)
    }

    /**
     * Cause a failure, but return false so it can be used in an assert statement.
     * @param msg message to output.
     * @return false, always
     * @throws IllegalStateException if we reach this state
     */
    fun assertFail(msg: String?): Boolean {
        fail(msg)
        return false
    }
}
